package SnakesAndLadders.Entities;

public class Ladder extends BoardEntity{

    Ladder(int startPos, int endPos) {
        super(startPos,endPos);
    }
}
