package ObserverPattern.Observer;

public interface Observer {

    public abstract void update(int temp);
}
