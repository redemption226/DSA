package SingletonPattern;

public class LoggerController {
    public static void main(String[] args) {
        Logger logger = Logger.getLogger();
        logger.log("Hello World");
    }



}
