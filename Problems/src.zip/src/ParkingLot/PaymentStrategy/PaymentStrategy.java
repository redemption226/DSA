package ParkingLot.PaymentStrategy;

public interface PaymentStrategy {
    boolean processPayment(double payment);
}
