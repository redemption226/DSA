package DecoratorPattern.Component;

public interface Coffee {
    double getCost();
    String printType();
}
