package ParkingLot.Constants;

public enum VehicleType {
    CAR, TRUCK, ELECTRIC, VAN, MOTORBIKE
}
