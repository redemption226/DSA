package ChainOfResponsibility.Constants;

public enum LogLevel {
    ERROR,WARN,INFO, DEBUG
}
