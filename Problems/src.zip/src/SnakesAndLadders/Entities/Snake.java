package SnakesAndLadders.Entities;

public class Snake extends BoardEntity{

    Snake(int startPos, int endPos) {
        super(startPos,endPos);
    }
}
